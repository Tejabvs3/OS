#include<pthread.h>
#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

 typedef struct arguments {
      int a;
      int b;
      int pointer;
 } arg ;

int pn[1000]; int c =0;

int perfect_number(int p)
{
  
 int i,  sum = 0 ;   
 for(i = 1 ; i <p ; i++)   
  {   
   if(p % i == 0)   
     sum = sum + i ;   
  }    

  if (sum == p)    return 1; 
  else   return 0;
}

void* thread_process(void *arguments)
 {
   arg*p = (arg*)arguments;
   
   int u; int n = p->a, k = p->b; int g = p->pointer; int w = g*(n/k);
  
   if(g!= (k-1))  u = n/k;
   else u = n - ((k-1)*(n/k));

   int numbers[u];
   for(int i=0;i<u;i++)
     {
        numbers[i] = w+1;
        w++;
     }

       char filename[1000];
       snprintf(filename,sizeof(filename),"OutFile%d.txt",g+1);

    for(int i=0;i<u;i++)
   {
       if(perfect_number(numbers[i]))
        {
           pthread_mutex_lock(&lock);
            pn[c] = numbers[i]; 
            c++;
           pthread_mutex_unlock(&lock);
           FILE *ptr;
             ptr = fopen(filename, "a");
             fprintf(ptr,"%d:Is a perfect number\n",numbers[i]);
             fclose(ptr);
        }
     else 
        {
          FILE *ptr;
             ptr = fopen(filename, "a");
             fprintf(ptr,"%d:Not a perfect number\n",numbers[i]);
             fclose(ptr);
         }
     
    }

}


int main() {

// this main program opens a file named "input.txt" and reads N and K seperated by a space and calls the main process.

  int n,k;
   FILE* ptr;
   ptr = fopen("input.txt", "r");  
   fscanf(ptr, "%d %d",&n,&k); 
   fclose(ptr); 

  // creating k threads //
 
   pthread_t thread[k]; 
   
   arg threads[k];  

    for(int i=0;i<k;i++)
    {
       threads[i].pointer = i;
       threads[i].a = n;
       threads[i].b = k;

       pthread_create(&thread[i], NULL, thread_process,(void*)&threads[i]);
  
    }
  
    for(int i=0;i<k;i++) 
      {
          pthread_join(thread[i],NULL); 

      }

 // the below code is to output the "OutMain file"
  
   int v=0; int e;

     for(int l=0;l<k;l++)
     {
       
       if(l != k-1)  e = (l+1)*(n/k);
       else    e = n; 
     
       FILE *ptr;
       ptr = fopen("OutMain.txt", "a");
       fprintf(ptr,"\nThread%d: ",l+1);
       fclose(ptr);
         
       for(int z=0;v<c;z++) 
         {  
           
          if((e/(pn[v]))>=1) 
           { 
           
             FILE *ptr;
             ptr = fopen("OutMain.txt", "a");
             fprintf(ptr,"num%d ",pn[v]);
             v++;
             fclose(ptr);
           }
          else break;
        }
        
     }

 return 0;

 }